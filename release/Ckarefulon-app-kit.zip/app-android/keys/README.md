# keys/

签名私钥（`Ckarefulon.keystore` / `keystore.properties`）**不在这个包里**，只留在原机器的本机目录中。

换机器重建发布版时必须先把这两份文件拷过来，否则会生成一张新证书，
老用户就无法覆盖安装（必须卸载重装）。见 HANDOFF §6 / §7。

缺失时可用 `node scripts/make-keystore.mjs` 重新生成——但那是**换证书**，慎用。
